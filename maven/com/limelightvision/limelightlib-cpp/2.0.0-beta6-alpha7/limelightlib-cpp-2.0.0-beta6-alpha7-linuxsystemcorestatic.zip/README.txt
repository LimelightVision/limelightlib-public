limelightlib-cpp is a header-only library. This artifact intentionally contains no compiled objects.
